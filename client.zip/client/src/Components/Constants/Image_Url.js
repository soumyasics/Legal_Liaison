//local

export const imageUrl= 'http://localhost:4043';

//server

// export const imageUrl= 'http://hybrid.srishticampus.in:4043'; 

