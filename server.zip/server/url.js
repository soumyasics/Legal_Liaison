// const baseUrl='http://hybrid.srishticampus.in:4043'
const baseUrl='http://localhost:4043'

module.exports={baseUrl}